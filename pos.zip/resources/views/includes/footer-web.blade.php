<div class="email-footer">
    <div class="container">
      <div class="row">
        <div class="col-md-12">Copyright © {{date('Y')}}  {{ config('app.name') }}. All rights reserved</div>
      </div>
    </div>
</div>