
<?php $__env->startSection('content'); ?>
    <div class="header">


        <!-- Body -->
        <div class="header-body">
            <div class="row  ">
                <div class="col">
                    <!-- Pretitle -->
                    <h6 class="header-pretitle">
                        Overview
                    </h6>
                    <!-- Title -->
                    <h1 class="header-title">
                        <h2 class="_head01">Sale <span>Management</span></h2>
                    </h1>
                </div>
                <div class="col-auto">
                    <ol class="breadcrumb">
                        <li><a href="#"><span>Sale</span></a></li>
                        <li><span>Active</span></li>
                    </ol>
                </div>
            </div>
        </div>


</div>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="header mb-0">
                <!-- <a class="btn add_button openDataSidebarForAddingProduct"><i class="fa fa-plus"></i> New  Product</a> -->
                <h2>Sales List</h2>
              <a href="<?php echo e(route('sale-add')); ?>" type="submit" class="btn btn-primary mr-2 add-new-sale" style="font-size: 13px;padding: 6px 11px 4px 9px;margin-top: -10px; float: right;">Add New</a>

            </div>
            <!--<div class="loader-div" id="tblLoader">
                            <div class="lds-ring" aria-role="none">
                              <div></div>
                              <div></div>
                              <div></div>
                              <div></div>
                              <div></div>
                            </div>
                          </div> -->
            <div class="body" >
            <table class="table table-hover dt-responsive nowrap subCatsListTable" style="width:100%;" id="example">
                <thead>
                    <tr>
                        <th>Customer Name</th>
                        <th>Invoice #</th>
                        <th>Received</th>
                        <th>Product Net Total</th>
                        <!-- <th>Invoice Total</th> -->
                        <th>Action</th>
                    </tr>
                </thead>
            <tbody>
                <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php  $parts              =     explode('-', $sale->invoice_no);
                      $invoice_first_part =     $parts[0];
                       ?>
                <tr>
                    <td><?php echo e($invoice_first_part); ?> (<?php echo e($sale->created_at->format('h:i A')); ?>)</td>
                    <td><?php echo e($sale->customer_name); ?></td>
                    <td style="font-family: 'Rationale', sans-serif !important;font-size: 20px;"><?php echo e($sale->paid_amount); ?> </td>
                    <td style="font-family: 'Rationale', sans-serif !important;font-size: 20px;"><?php echo e($sale->product_net_total +$sale->service_charges - $sale->invoice_discount); ?> </td>
                    <!-- <td style="font-family: 'Rationale', sans-serif !important;font-size: 20px;"><?php echo e($sale->total_invoice_amount); ?> </td> -->
                    <td>
                        
                        <a id="<?php echo e($sale->id); ?>" class="btn btn-default <?php echo e($sale->is_editable== 1 ? 'btn-line'  : ''); ?>" href="<?php echo e($sale->is_editable== 1 ? route('sale-edit' ,['id'=>$sale->id]) : route('sale-edit' ,['id'=>$sale->id ,'invoice' => 'detail'])); ?>"><?php echo e($sale->is_editable== 1  ? 'Edit'  : "Detail"); ?></a>
                        <!-- <a id="<?php echo e($sale->id); ?>" class="btn btn-default " href="<?php echo e(route('sale-detail' ,['id'=>$sale->id])); ?>">Detail</a> -->
                        <button id="<?php echo e($sale->id); ?>" data-invoice="<?php echo e($sale->id); ?>" data-customer-id="<?php echo e($sale->customer_id); ?>"
                         paid-amount="<?php echo e($sale->paid_amount); ?>" class="btn btn-default print-invoice">Print</button>
                        <!-- <button type="button" id="<?php echo e($sale->id); ?>" class="btn btn-default red-bg  delete_product" name="Sub_cat" title="Delete">Delete</button> -->
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $('.print-invoice').on('click', function() {
            var invoice_id = $(this).attr('data-invoice');
            var customer_id = $(this).attr('data-customer-id');
            var invoice_id = $(this).attr('data-invoice');
            var paid_amount = $(this).attr('paid-amount');
            var printWindow = window.open("/print-sale-invoice/" + invoice_id + '/' + customer_id + '/' +
                paid_amount);
            printWindow.onload = function() {
                printWindow.print();
                // printWindow.close();
            };
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\pos\resources\views/sales/list.blade.php ENDPATH**/ ?>